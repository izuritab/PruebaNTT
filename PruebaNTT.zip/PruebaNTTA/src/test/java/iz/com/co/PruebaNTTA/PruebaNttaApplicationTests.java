package iz.com.co.PruebaNTTA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaNttaApplicationTests {

	@Test
	void contextLoads() {
	}

}
