/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package iz.com.co.PruebaNTTA;

import org.springframework.stereotype.Service;

/**
 *
 * @author ivan
 */
@Service
public interface AdnService {
    public Respuesta validarMutacion(String adn);
}
