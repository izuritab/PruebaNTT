/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package iz.com.co.PruebaNTTA;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author ivan
 */

//Clase servicio donde invoca al DAO
@Service
public class adnServiceImpl implements AdnService {

    @Autowired
    private AdnDAO adndao;
    
    @Override
    public Respuesta validarMutacion(String adn) {
       
        
        return adndao.validarMutacion(adn);
    }
    
    
 
    
    
}
