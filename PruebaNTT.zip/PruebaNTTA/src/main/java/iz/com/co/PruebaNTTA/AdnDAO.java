/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package iz.com.co.PruebaNTTA;

import java.util.ArrayList;
import org.springframework.stereotype.Component;

/**
 *
 * @author ivan
 */
//Clase DAO donde hace todo el proceso recorrer y encontrar mutacion.
@Component
public class AdnDAO {

    private static adn matrizadn[][];
    ArrayList mutaciones1 = new ArrayList();


    public Respuesta validarMutacion(String adn) {
        boolean mutant = false;
        ArrayList messages = new ArrayList();

        Respuesta respuesta = new Respuesta();
        setMatrizAdn(adn);
       
        recorrermatrizizqhorizontal();
        recorrermatrizderhorizontal();
        recorrermatrizabajovertical();
        recorrermatrizarribavertical();
        recorrerdiagonal();
        if (!mutaciones1.isEmpty()) {
            mutant = true;
            for (int i = 0; i < mutaciones1.size(); i++) {
                messages.add(mutaciones1.get(i).toString());
            }
        }
         respuesta.setMutant(mutant);
      
        respuesta.setMessages(messages);
        imprimirmatriz();
      
        return respuesta;
    }

    public void setMatrizAdn(String adn) {

        String adn1 = adn.replaceAll("\\s", "");
        String adn2 = adn1.substring(8, adn1.length() - 2);
        String[] arrSplit = adn2.split(",");
        
        matrizadn = new adn[arrSplit[0].length() - 2][arrSplit.length];
        for (int f = 0; f < matrizadn.length; f++) {
            for (int c = 0; c < matrizadn[0].length; c++) {
                BaseProteica baseproteica = new BaseProteica();

                baseproteica.setPosicionx(String.valueOf(c));
                baseproteica.setPosiciony(String.valueOf(f));
                baseproteica.setBaseproteica(arrSplit[f].charAt(c + 1));
                adn adnobj = new adn();
                adnobj.setBaseproteica(baseproteica);
                matrizadn[f][c] = adnobj;

            }
        }
       
    }

    public  void encontrarMutacion(ArrayList aux, String recorrido) {
       // String message="";
      
        ArrayList mut1 = new ArrayList();
        mut1.add('A');
        mut1.add('A');
        mut1.add('A');
        mut1.add('A');

        ArrayList mut2 = new ArrayList();
        mut2.add('T');
        mut2.add('T');
        mut2.add('T');
        mut2.add('T');

        ArrayList mut3 = new ArrayList();
        mut3.add('C');
        mut3.add('C');
        mut3.add('C');
        mut3.add('C');

        ArrayList mut4 = new ArrayList();
        mut4.add('G');
        mut4.add('G');
        mut4.add('G');
        mut4.add('G');

        ArrayList auxnew = new ArrayList();
        ArrayList<adn> coordenadas=new ArrayList();
        for (int i = 0; i <4; i++) {
             adn adnobj = new adn();
             adnobj=(adn)aux.get(i);
             coordenadas.add(adnobj);
             BaseProteica baseproteica = new BaseProteica();
             baseproteica=adnobj.getBaseproteica();
             auxnew.add(baseproteica.getBaseproteica());
        }
        if (mut1.equals(auxnew)) {
            
         //message="Existe mutacion en direccion"+recorrido+ "en coordenadas" + "("+coordenadas.get(0).getBaseproteica().getPosicionx()+","+coordenadas.get(0).getBaseproteica().getPosicionx();
         mutaciones1.add("Existe mutacion en direccion "+recorrido+ " en coordenadas " + " ("+coordenadas.get(0).getBaseproteica().getPosicionx()+","+coordenadas.get(0).getBaseproteica().getPosiciony()+")");
        }
        if (mut2.equals(auxnew)) {
           mutaciones1.add("Existe mutacion en direccion "+recorrido+ " en coordenadas " + " ("+coordenadas.get(0).getBaseproteica().getPosicionx()+","+coordenadas.get(0).getBaseproteica().getPosiciony()+")");
        }
        if (mut3.equals(auxnew)) {
          mutaciones1.add("Existe mutacion en direccion "+recorrido+ " en coordenadas " + " ("+coordenadas.get(0).getBaseproteica().getPosicionx()+","+coordenadas.get(0).getBaseproteica().getPosiciony()+")");
        }
        if (mut4.equals(auxnew)) {
           mutaciones1.add("Existe mutacion en direccion "+recorrido+ " en coordenadas " + " ("+coordenadas.get(0).getBaseproteica().getPosicionx()+","+coordenadas.get(0).getBaseproteica().getPosiciony()+")");
        }
        //return message;
    }

    public  void recorrermatrizizqhorizontal() {
        
        ArrayList aux1 = new ArrayList();
       
      
        for (int c = 0; c < matrizadn.length; c++) {
            for (int f = 0; f < matrizadn.length; f++) {
                //System.out.println(matriz[c][f]);
                aux1.add(matrizadn[c][f]);
                if (aux1.size() == matrizadn[0].length) {
                  encontrarMutacion(aux1, "horizontal");
                   
                    aux1.clear();
                }
            }
        
        }
    }
public  void recorrermatrizderhorizontal(){
     ArrayList aux=new ArrayList();
    for(int c=5;c>=0;c--){
    for(int f=5;f>=0;f--){
         aux.add(matrizadn[c][f]);
                if (aux.size() == matrizadn[0].length) {
                  encontrarMutacion(aux, "horizontal");
                   
                    aux.clear();
                }
    }
    }
}
public  void recorrermatrizabajovertical(){
     ArrayList aux=new ArrayList();
    for(int c=0;c<matrizadn.length;c++){
    for(int f=matrizadn.length-1;f>=0;f--){
         aux.add(matrizadn[f][c]);
                if (aux.size() == matrizadn[0].length) {
                  encontrarMutacion(aux, "vertical");
                   
                    aux.clear();
                }
    }
    
    }
}
public  void recorrermatrizarribavertical(){
     ArrayList aux=new ArrayList();
    for(int c=0;c<matrizadn.length;c++){
    for(int f=0;f<matrizadn.length;f++){
          aux.add(matrizadn[f][c]);
                if (aux.size() == matrizadn[0].length) {
                  encontrarMutacion(aux, "vertical");
                   
                    aux.clear();
                }
    }
    }
}
public  void recorrerdiagonal(){
     ArrayList aux=new ArrayList();
  int altura = matrizadn.length, anchura = matrizadn[0].length;
        for (int diagonal = 1-anchura; diagonal < altura; diagonal += 1) 
        {
            
            for ( 
                    
                    int vertical = Math.max(0, diagonal), horizontal = -Math.min(0, diagonal);
                    vertical < altura && horizontal < anchura; // Mientras no excedan los límites.
                    vertical += 1, horizontal += 1 // Avanza en diagonal incrementando ambos ejes.
                    ) {
             
               aux.add(matrizadn[vertical][horizontal]);
             
            }
         if(aux.size()>=4){
                   encontrarMutacion(aux,"diagonal");
               }else{
             aux.clear();
         }
            aux.clear();
        }
}
    public void imprimirmatriz() {

        for (int x = 0; x < matrizadn.length; x++) {
            for (int y = 0; y < matrizadn[x].length; y++) {
                System.out.print(matrizadn[x][y].getBaseproteica().getBaseproteica());
              
            }
            System.out.println();
        }
    }
}
