/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package iz.com.co.PruebaNTTA;

/**
 *
 * @author ivan
 */
public class adn {
    
    private BaseProteica baseproteica;

    public BaseProteica getBaseproteica() {
        return baseproteica;
    }

    public void setBaseproteica(BaseProteica baseproteica) {
        this.baseproteica = baseproteica;
    }
    
    
}
