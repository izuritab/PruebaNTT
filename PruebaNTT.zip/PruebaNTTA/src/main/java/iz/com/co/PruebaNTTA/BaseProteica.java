/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package iz.com.co.PruebaNTTA;

/**
 *
 * @author ivan
 */
public class BaseProteica {

    private char baseproteica;

    public String getPosicionx() {
        return posicionx;
    }

    public void setPosicionx(String posicionx) {
        this.posicionx = posicionx;
    }

    public String getPosiciony() {
        return posiciony;
    }

    public void setPosiciony(String posiciony) {
        this.posiciony = posiciony;
    }
    private String posicionx;
    private String posiciony;
    public char getBaseproteica() {
        return baseproteica;
    }

    public void setBaseproteica(char baseproteica) {
        this.baseproteica = baseproteica;
    }

   

}
